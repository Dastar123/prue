package com.example.cynthia_burguer.Controladores;

import com.example.cynthia_burguer.Elementos.Pantallas;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;

import java.io.IOException;

public class ControladorClienteOadmin {
    public Button BotonClientes;
    public Button BotonAdministradores;

    public void ClientesPantalla(ActionEvent actionEvent) {
        try {
            Pantallas.CambiarPantalla("/com/example/Cynthia_Burguer/InicioDeSesionCliente.fxml","Inicio de sesión Cliente");
            Pantallas.cerrarVentana(BotonClientes);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void AdministradoresPantalla(ActionEvent actionEvent) {

        try {
            Pantallas.CambiarPantalla("/com/example/Cynthia_Burguer/InicioDeSesionAdministrador.fxml","Inicio de sesión Administrador");
            Pantallas.cerrarVentana(BotonAdministradores);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
