package com.example.cynthia_burguer.Controladores;

import com.example.cynthia_burguer.Elementos.Pantallas;
import com.example.cynthia_burguer.Elementos.SentenciasSql;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.io.IOException;

public class ControladorInicioDeSesionCliente {

    public Button EntrarButton;
    public TextField NombreField;
    public TextField contraField;
    public static boolean InicioSesionCompletado=false;

    public void CrearCuenta(ActionEvent actionEvent) {
        try {
            Pantallas.CambiarPantalla("/com/example/Cynthia_Burguer/CrearCuentaCliente.fxml","Crear Cuenta de Cliente");
            Pantallas.cerrarVentana(EntrarButton);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void Login(ActionEvent actionEvent) {
        try {
            if(SentenciasSql.verificarCredencialesCliente(NombreField.getText(),contraField.getText())==true){
                InicioSesionCompletado=true;
                PantallaDeComprasControlador.InicioSesion(InicioSesionCompletado);

                Pantallas.CambiarPantalla("/com/example/Cynthia_Burguer/PantallaDeCompras.fxml","Pedidos");
                Pantallas.cerrarVentana(EntrarButton);

            }
            else {
                Pantallas.mostrarAlerta("Error", "Error", "No existe ese nombre de usuario o contraseña en la base de datos");
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
