module com.example.cynthia_burguer {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.cynthia_burguer to javafx.fxml;
    exports com.example.cynthia_burguer;
    exports com.example.cynthia_burguer.Controladores;
    opens com.example.cynthia_burguer.Controladores to javafx.fxml;
    opens com.example.cynthia_burguer.Elementos to javafx.base;
}